
#what happens when a recipe is run from Python to RoboDK
def run_recipe_in_robodk(recipe_name, heat_level):
    try:
        RDK = run_recipe_in_robodk().Robolink()
        robot = RDK.Item(ROBOTIC_ARM_NAME, robolink.ITEM_TYPE_ROBOT)
        if not robot.Valid():
            raise Exception("UR10e robot not found in RoboDK station.")

        #increase the speed
        robot.setSpeed(1000)  #linear speed in mm/s
        robot.setSpeedJoints(280)  #joint speed in deg/s


        #the sequence for the Omelette recipe
        if recipe_name == "Omelette":
            sequence = [
                ("Attach tool", "Attaching the gripper..."), #"name of the program in RoboDK", "Name of the step displayed"
                ("__GAS_ON__", "Turning on the gas..."),
                ("placing bowl", "Placing the pan on the stove..."),
                ("Picking Bottle", "Adding oil to the pan..."),
                ("ing 1", "Adding the cracked eggs..."),
                ("Detach Tool", "Removing the Gripper..."),
                ("Attach tool", "Attaching the Whisk..."),
                ("Whisking Motion", "Whisking the eggs..."),
                ("Detach Tool", "Removing the whisk..."),
                ("Attach tool", "Attaching the gripper..."),
                ("ing 2", "Adding chopped tomatoes..."),
                ("Detach Tool", "Detaching the Gripper..."),
                ("2 Attach Tool", "Attaching the Stirrer..."),
                ("Stirring Motion", "Stirring the omelette..."),
                ("2 Detach Tool", "Detaching the Stirrer..."),
                ("Attach tool", "Attaching the Gripper..."),
                ("Picking Bottle", "Adding Salt..."),
                ("Picking Bottle", "Adding Pepper..."),
                ("Detach Tool", "Detaching gripper..."),
                ("2 Attach Tool", "Attaching the Spatula..."),
                ("Fold Motion", "Folding the omelette..."),
                ("2 Detach Tool", "Detaching the Spatula..."),
                ("Attach tool", "Attaching the gripper..."),
                ("__GAS_OFF__", "Turning off the gas..."),
                ("Detach Tool", "Detaching the gripper...")
            ]

            gas_on_prog = heat_level + "Flame"  #setting the heat level
            gas_off_prog = gas_on_prog

            #the sequence for a French Toast
        elif recipe_name == "French Toast":
            sequence = [
                ("Attach tool", "Attaching Gripper..."),
                ("placing bowl", "Getting a Bowl..."),
                # ("ing 1", "Adding cracked eggs..."),
                # ("Picking Bottle", "Adding salt..."),
                # ("Picking Bottle", "Adding sugar..."),
                # ("Picking Bottle", "Adding pepper..."),
                # ("Picking Bottle", "Adding cinnamon..."),
                # ("Picking Bottle", "Pouring milk..."),
                # ("Detach Tool", "Detaching the Gripper..."),
                # ("Attach tool", "Attaching the Whisk..."),
                # ("Whisking Motion", "Whisking the coating mixture..."),
                # ("Detach Tool", "Detaching the Whisk..."),
                # ("2 Attach Tool", "Attaching the Spatula..."),
                # ("ing 2", "Adding the Bread to the coating mixture..."),
                # ("Flipping Motion", "Coating the bread in the mixture..."),
                # ("2 Detach Tool", "Detaching the Spatula..."),
                ("replace all", "Clearing out the workstation to begin frying..."),
                # ask user for the gas level
                ("Attach tool", "Attaching the Gripper..."),
                ("__GAS_ON__", "Turning on the gas..."),
                ("placing bowl", "Grabbing the pan..."),
                ("Detach Tool", "Detaching the Gripper..."),
                ("2 Attach Tool", "Attaching the Spatula..."),
                ("ing 2", "Adding the coated bread..."),
                ("Flipping Motion", "FLipping the French Toast..."),
                ("2 Detach Tool", "Detaching the Spatula..."),
                ("Attach tool", "Attaching the Gripper..."),
                ("__GAS_OFF__", "Turning off the gas..."),
                ("Detach Tool", "Detaching the Gripper...")
            ]
            gas_on_prog = heat_level + "Flame"
            gas_off_prog = gas_on_prog
        else:
            messagebox.showwarning("Unavailable", f"No RoboDK sequence defined for {recipe_name}.")
            return

        if not detect_tool_or_ingredient():
            messagebox.showerror("Detection Error", "Required tools/ingredients not detected.")
            return

        for flame_name in ["LowFlame", "MedFlame", "HighFlame"]:
            flame_item = RDK.Item(flame_name, robolink.ITEM_TYPE_OBJECT)
            if flame_item.Valid():
                flame_item.setVisible(False)

        flame_prog_on = RDK.Item(gas_on_prog, robolink.ITEM_TYPE_PROGRAM)
        flame_prog_off = flame_prog_on


        #the cooking progress window once a recipe starts
        progress_win = tk.Toplevel(root)
        progress_win.title("Cooking Progress")
        progress_win.geometry("420x200")
        progress_win.configure(bg="white")
        progress_win.grab_set()
        progress_win.attributes('-toolwindow', 1)

        msg_label = tk.Label(progress_win, text="Starting...", font=("Segoe UI", 12), bg="white")
        msg_label.pack(pady=(20, 10))
        progress_bar = ttk.Progressbar(progress_win, orient="horizontal", length=300, mode="determinate")
        progress_bar.pack(pady=(0, 20))
        progress_bar["maximum"] = len(sequence)
        progress_bar["value"] = 0

        #emergency stop on the cooking progress window to stop any activities
        stop_flag = {"stop": False}
        def emergency_stop():
            stop_flag["stop"] = True
            msg_label.config(text="Emergency stop activated.")
            progress_bar.stop()
            stop_btn.config(state="disabled")
            RDK.StopAll()

        stop_btn = tk.Button(progress_win, text="EMERGENCY STOP", bg="red", fg="white",
                             font=("Segoe UI", 10, "bold"), command=emergency_stop)
        stop_btn.pack()

        def execute_step(index=0):
            if stop_flag["stop"]:
                return

            if index >= len(sequence):
                msg_label.config(text="Cooking complete!")
                stop_btn.config(state="disabled")
                return

            prog_name, custom_text = sequence[index]
            msg_label.config(text=custom_text)
            print(f"Executing step {index + 1}/{len(sequence)}: {custom_text}")
            progress_bar["value"] = index + 1
            progress_win.update()

            # Ask for gas level just before turning on the gas for French Toast
            # Special logic for French Toast: Ask gas level ONLY after "replace all"
            if recipe_name == "French Toast" and prog_name == "replace all" and not hasattr(execute_step,
                                                                                            "replace_all_done"):
                # Mark "replace all" step as completed
                execute_step.replace_all_done = True
                prog = RDK.Item(prog_name, robolink.ITEM_TYPE_PROGRAM)
                if prog.Valid():
                    prog.RunProgram()
                    prog.WaitFinished()

                # Now show gas prompt after replace all is done
                def show_stove_prompt_and_continue():
                    stove_popup = tk.Toplevel(root)
                    stove_popup.title("Electric Stove")
                    stove_popup.configure(bg="white")
                    stove_popup.geometry("320x320")
                    stove_popup.attributes('-toolwindow', 1)
                    stove_popup.grab_set()

                    tk.Label(stove_popup, text="Please select the heat level:", bg="white",
                             font=("Segoe UI", 11)).pack(pady=(20, 10))

                    def set_gas_level(level):
                        nonlocal gas_on_prog, gas_off_prog, flame_prog_on, flame_prog_off
                        stove_popup.destroy()
                        selected_prog = level + "Flame"
                        gas_on_prog = selected_prog
                        gas_off_prog = selected_prog
                        flame_prog_on = RDK.Item(selected_prog, robolink.ITEM_TYPE_PROGRAM)
                        flame_prog_off = flame_prog_on
                        execute_step.gas_level_chosen = True
                        progress_win.after(100, execute_step, index + 1)

                    for level in ["Low", "Medium", "High"]:
                        tk.Button(stove_popup, text=level, width=12, bg="#1E88E5", fg="white",
                                  font=("Segoe UI", 10, "bold"),
                                  command=lambda l=level: set_gas_level(l)).pack(pady=8)

                show_stove_prompt_and_continue()
                return

            # Wait until gas level is selected before proceeding past replace all
            if recipe_name == "French Toast" and not getattr(execute_step, "gas_level_chosen", False) and index > 16:
                return


            #heat level execution
            if prog_name == "__GAS_ON__":
                if flame_prog_on.Valid():
                    flame_prog_on.RunProgram()
                    flame_prog_on.WaitFinished()
            elif prog_name == "__GAS_OFF__":
                if flame_prog_off.Valid():
                    flame_prog_off.RunProgram()
                    flame_prog_off.WaitFinished()

            else:
                prog = RDK.Item(prog_name, robolink.ITEM_TYPE_PROGRAM)
                if not prog.Valid():
                    messagebox.showerror("RoboDK Error", f"Program '{prog_name}' not found.")
                    progress_win.destroy()
                    return
                prog.RunProgram()
                prog.WaitFinished()

            progress_win.after(100, execute_step, index + 1)

        execute_step()
    except Exception as e:
        messagebox.showerror("RoboDK Error", str(e))

